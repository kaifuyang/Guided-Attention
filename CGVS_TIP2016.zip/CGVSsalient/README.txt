INTRODUCTION
===================================================================================

This code is provided for research purpose only.
This code performs Contour-Guided Visual Search (CGVS)
reported in:
  Kai-Fu Yang, Hui Li, Chao-Yi Li, and Yong-Jie Li*. 
  A Unified Framework for Salient Structure Detection by Contour-Guided Visual Search. 
  TIP,25(8):3475-3488,2016.

Please cite our paper if this code is used to motivate any publications.

===================================================================================
USAGE��

run "example.m" for examples of salient structure detection by CGVS.

Let us know if you have any questions at
Kaifu Yang <yangkf@uestc.edu.cn>

===================================================================================
NOTES:
 We have repaired some bugs in the original code, so the results will be silghtly different (better) with that reported in the paper(TIP'2016).